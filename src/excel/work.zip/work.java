package excel;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class work {
	
	public static void main (String[]args) throws IOException, InterruptedException {
		System.getProperty("webdriver.chrome.driver","C:\\Users\\srika\\OneDrive\\Desktop\\shree\\chromedriver-win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.automationtesting.in/Register.html");
		
		FileInputStream ip =new FileInputStream("C:\\Users\\srika\\.eclipse\\Selenium\\excel\\levitica.xlsx");
		
		XSSFWorkbook workbook = new XSSFWorkbook(ip);
		XSSFSheet sheet = workbook.getSheetAt(0);
		
		int rowCount =sheet.getLastRowNum();
		
		for(int i=1;i<=rowCount;i++) {
			
			XSSFRow currentRow=sheet.getRow(i);
			String FirstName=currentRow.getCell(0).getStringCellValue();
			System.out.println(FirstName);
		    String LastName	=currentRow.getCell(1).getStringCellValue();
		    System.out.println(LastName);
		    
		    driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(FirstName);
		    driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(LastName);
		   Thread.sleep(4000);
		   
		    
		    
		}
		workbook.close();
	}

}
